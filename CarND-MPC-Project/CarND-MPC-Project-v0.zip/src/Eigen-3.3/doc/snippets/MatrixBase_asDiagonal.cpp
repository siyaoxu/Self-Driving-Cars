cout << Matrix3i(Vector3i(2,5,6).asDiagonal()) << endl;
