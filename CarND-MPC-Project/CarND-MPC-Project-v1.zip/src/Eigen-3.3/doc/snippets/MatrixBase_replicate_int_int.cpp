Vector3i v = Vector3i::Random();
cout << "Here is the vector v:" << endl << v << endl;
cout << "v.replicate(2,5) = ..." << endl;
cout << v.replicate(2,5) << endl;
